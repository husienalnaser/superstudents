package com.example.asuper;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class test extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test2);
        Button next=findViewById(R.id.buutoom);
        final TextView name=findViewById(R.id.name);
        final TextView age=findViewById(R.id.age);
        final TextView blood=findViewById(R.id.blood);
        final TextView num=findViewById(R.id.phone);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(test.this,MainActivity.class);
                intent.putExtra("name",name.getText().toString());
                intent.putExtra("age",age.getText().toString());
                intent.putExtra("blood",blood.getText().toString());
                intent.putExtra("num",num.getText().toString());
                startActivity(intent);
            }
        });
    }
}